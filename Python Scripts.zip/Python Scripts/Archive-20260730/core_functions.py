#Defining Main Functions
#Importing Other Libraries
from simple_salesforce import Salesforce,SalesforceLogin,SalesforceAuthenticationFailed,SFType
import pandas as pd
import json
import numpy as np
import time as t
import uuid
import os
from sqlalchemy import create_engine, text
from sqlalchemy.engine import URL
from collections import OrderedDict
import logging

def connect_to_salesforce(username,password,token,url,domain,logger):
    """
    Establish a connection to a Salesforce instance using provided credentials.
  
    Parameters:
    - username (str): Salesforce username for authentication.
    - password (str): Salesforce password for authentication.
    - token (str): Salesforce security token for authentication.
    - url (str): Salesforce instance URL (e.g., 'https://instance.my.salesforce.com').
    - domain (str): Salesforce domain, typically 'login' or 'test' for sandbox.
    - logger (logging.Logger): Logger instance for logging messages.

    Returns:
    - Salesforce: An authenticated Salesforce instance object for API operations.
    """
    if not (username and password and token and url and domain):
        raise RuntimeError(
            "Missing Salesforce credentials. Set SF_USERNAME, SF_PASSWORD, SF_SECURITY_TOKEN (and SF_URL and SF_DOMAIN if needed)."
        )

    try:
        sf = Salesforce(
                username       = username
               ,password       = password
               ,security_token = token
               ,instance_url   = url
               ,domain         = domain
               ,version="59.0"  # specify API version if needed, or leave default
               )
  
        logger.info(f"Connected successfully to {url}")
        return sf
    except SalesforceAuthenticationFailed as e:
        logger.error(f"Authentication failed: {e}")
        raise
    except Exception as e:
        logger.error(f"Unexpected error during connection: {e}")
        raise
 
 
def extract_query(sf_instance, soql_query,logger):
    """
    Execute a SOQL query on a Salesforce instance and return results as a DataFrame.
 
 
    Parameters:
    - sf_instance (Salesforce): Authenticated Salesforce instance to query.
    - soql_query (str): SOQL query string to execute (e.g., 'SELECT Id, Name FROM Account').
 
 
    Returns:
    - pandas.DataFrame: DataFrame containing query results, with 'attributes' column dropped.
    """
    try:
      start_time = t.time()
      logger.info(f"Executing SOQL query: {soql_query}")
      result = sf_instance.query(soql_query)
      records = result['records']
 
 
      while not result['done']:
          logger.info(f"Fetching next batch: {result['nextRecordsUrl']}")
          result = sf_instance.query_more(result['nextRecordsUrl'], identifier_is_url=True)
          records.extend(result['records'])
 
 
      df = pd.DataFrame(records).drop('attributes', axis=1, errors='ignore')
      logger.info(f"Query complete. Rows extracted: {len(df)} . Time taken: {t.time() - start_time:.2f}s")
      return df
    except Exception as e:
      logger.error(f"Error during query execution: {e}")
      raise
 
def extract_fieldlist_metadata(query_result: dict) -> pd.DataFrame:
    records = query_result.get("records", [])
    rows = []

    for r in records:
        # Object API name (nested)
        object_api_name = r.get("EntityDefinition").get("QualifiedApiName") if r.get("EntityDefinition") else None

        # Field API name (nested)
        field_api_name = r.get("QualifiedApiName")

        # Picklist value attributes
        rows.append({
            "object_api_name": object_api_name,
            "field_api_name": field_api_name,
            "data_type": r.get("DataType"),
            "label": r.get("Label"),
            "description": r.get("Description"),
            "precision": r.get("Precision"),
            "scale": r.get("Scale"),
            "length": r.get("Length"),
            "is_nillable": r.get("IsNillable"),
            "is_calculated": r.get("IsCalculated"),
            "reference_to": r.get("ReferenceTo")
        })

    return pd.DataFrame(rows)

def extract_picklist_metadata(query_result: dict) -> pd.DataFrame:
    records = query_result.get("records", [])
    rows = []

    for r in records:
        # EntityParticle is nested under EntityParticle
        entity_particle = r.get("EntityParticle") or {}

        # Object API name (nested)
        entity_def = entity_particle.get("EntityDefinition") or {}
        object_api_name = entity_def.get("QualifiedApiName")

        # Field API name (nested)
        field_api_name = entity_particle.get("QualifiedApiName")
        field_is_unique = entity_particle.get("IsUnique")

        # Picklist value attributes
        rows.append({
            "object_api_name": object_api_name,
            "field_api_name": field_api_name,
            "field_is_unique": field_is_unique,
            "label": r.get("Label"),
            "value": r.get("Value"),
            "is_active": r.get("IsActive"),
            "is_default": r.get("IsDefaultValue")
        })

    return pd.DataFrame(rows)
 
def load_data(sf_instance, df, object_name, reference_field,fields, batch_size=1000, logger=None):
    """
    Load (Upsert) data to Salesforce with error handling and summary.
 
 
    Parameters:
    - sf_instance: Salesforce instance.
    - df: pandas DataFrame containing the data to upsert.
    - object_name: Salesforce object name (e.g., 'Account').
    - reference_field: Field used for upsert matching (e.g., 'External_ID__c').
    - fields: List of fields to include in the upsert (optional).
    - batch_size: Number of records per batch for upsert (default: 1000).
 
 
    Returns:
    - pandas DataFrame containing upsert results.
    """
 
 
    try:
       df = df[fields]
    except KeyError as e:
       logger.error(f"Error selecting fields {fields}: {e}")
       raise
 
 
    records = df.to_dict(orient='records')
    logger.info(f"Preparing to upsert {len(records)} records to {object_name} with fields {fields}")
 
 
    try:
        start_time = t.time()
        results = getattr(sf_instance.bulk, object_name).upsert(
            records,
            external_id_field=reference_field,
            batch_size=batch_size,
            use_serial=False  # For Parallel Processing - True for Serial Processing
        )
        logger.info(f"Upsert complete. Time taken: {t.time() - start_time:.2f}s")
 
 
        # Summarize results
        success_count = sum(1 for r in results if r['success'])
        failure_count = len(results) - success_count
        logger.info(f"Success: {success_count}, Failures: {failure_count}")
        if failure_count > 0:
            logger.warning(f"Failures: {[r for r in results if not r['success']]}")
 
 
        return pd.DataFrame(results)
    except Exception as e:
        logger.error(f"Error during upsert: {e}")
        raise

# ----------------------------
# 2) NORMALIZE df_meta COLUMNS (adjust mapping as needed)
# ----------------------------
def normalize_df(df_meta: pd.DataFrame) -> pd.DataFrame:
    df = df_meta.copy()

    # ReferenceTo / picklist_values to JSON strings for storage
    def to_json_or_str(v):
        if isinstance(v, (list, OrderedDict, dict)):
            return json.dumps(v, ensure_ascii=False)
        return v

    for col in df.columns:
        df[col] = df[col].map(to_json_or_str)

    return df

def get_engine(connection_string: str = None) -> create_engine:
    connection_url = URL.create(
        "mssql+pyodbc",
        query={"odbc_connect": connection_string}
    )
    # Enable fast_executemany on the connection
    engine = create_engine(connection_string, echo=True, future=True, fast_executemany=True)
    return engine

def write_append(engine, df_final: pd.DataFrame):
    # Simple 'append' (will insert duplicates if PK is not enforced)
    df_final.to_sql(
        name=p_tbl_fd,
        con=engine,
        schema=p_sch,
        if_exists="append",  # or 'replace' (drops and recreates)
        index=False,
        chunksize=WRITE_CHUNK_SIZE,
        method=None  # let SQLAlchemy/pyodbc handle batching
    )

def write_upsert(engine, df_final: pd.DataFrame, q_createTable: str, temp_sch: str, temp_table: str, q_tempTbl: str, q_mergeTbl: str):
    """
    Perform an UPSERT via a staging temp table + MERGE.
    """
    # collation = "Latin1_General_CI_AS"
    # q_tempTbl = f"""
    #     DROP TABLE if exists #stg_fd;
    #     CREATE TABLE #stg_fd (
    #         [EntityDefinition]      NVARCHAR(255) NULL,
    #         [QualifiedApiName]       NVARCHAR(255) NULL,
    #         [DataType]            NVARCHAR(100) NULL,
    #         [Label]          NVARCHAR(255) NULL,
    #         [Description]          NVARCHAR(255) NULL,
    #         [Precision]            INT NULL,
    #         [Scale]                INT NULL,
    #         [Length]               INT NULL,
    #         [IsNillable]             BIT NULL,
    #         [IsCalculated]           BIT NULL,
    #         [ReferenceTo]           NVARCHAR(MAX) NULL
    #     );
    # """
    # q_mergeTbl = f"""
    #     MERGE [{p_sch}].[{p_tbl_fd}] AS tgt
    #     USING #stg_fd AS src
    #     ON  tgt.EntityDefinition.QualifiedApiName = src.EntityDefinition.QualifiedApiName
    #     AND tgt.QualifiedApiName  = src.QualifiedApiName
    #     WHEN MATCHED THEN UPDATE SET
    #           tgt.Label         = src.Label
    #         , tgt.DataType           = src.DataType
    #         , tgt.Length              = src.Length
    #         , tgt.Precision           = src.Precision
    #         , tgt.Scale               = src.Scale
    #         , tgt.IsNillable            = src.IsNillable
    #         , tgt.unique_             = src.unique_
    #         , tgt.IsCalculated          = src.IsCalculated
    #         , tgt.IsCalculated_formula  = src.IsCalculated_formula
    #         , tgt.inline_help_text    = src.inline_help_text
    #         , tgt.ReferenceTo        = src.ReferenceTo
    #         , tgt.picklist_values     = src.picklist_values
    #     WHEN NOT MATCHED BY TARGET THEN
    #         INSERT (
    #             EntityDefinition.QualifiedApiName, QualifiedApiName, Label, DataType,
    #             Length, Precision, Scale, IsNillable, unique_, IsCalculated,
    #             IsCalculated_formula, inline_help_text, ReferenceTo, picklist_values
    #         )
    #         VALUES (
    #             src.EntityDefinition.QualifiedApiName, src.QualifiedApiName, src.Label, src.DataType,
    #             src.Length, src.Precision, src.Scale, src.IsNillable, src.unique_, src.IsCalculated,
    #             src.IsCalculated_formula, src.inline_help_text, src.ReferenceTo, src.picklist_values
    #         )
    #     ;
    # """

    with engine.begin() as conn:
        # 1) Create target table if missing
        conn.execute(text(q_createTable))

        # 2) Create temp table (structure mirrors target)
        conn.execute(text(q_tempTbl))
        conn.commit()
        # conn.close()

        # 3) Bulk load into temp table
        df_final.to_sql(
            schema=None,
            name=temp_table,
            # schema='ids',
            # name="sf_object_fd",
            con=engine,  # use raw connection for temp table visibility
            if_exists="append",
            index=False
        )

        # 4) MERGE into target (upsert on PK: EntityDefinition.QualifiedApiName + QualifiedApiName)
    with engine.begin() as conn:
        conn.execute(text(q_mergeTbl))
        conn.commit()
        conn.close()

def main(df_fd: pd.DataFrame, temp_fd: str, df_pl: pd.DataFrame, temp_pl: str):
    """
    Field Definitions
    """
    df_final = normalize_df(df_fd)

    engine = get_engine()
    # Extract Field Definitions
    if UPSERT_ENABLED:
        # Create temp table
        with engine.begin() as conn:
            conn.execute(text(q_sql_createTemp_fd))
            conn.commit()
            # write_upsert(engine, df_final, q_sql_createTable_fd, temp_fd, q_sql_createTemp_fd, q_sql_merge_fd)
            df_final.to_sql(
                schema='ids',
                name=temp_fd,
                con=engine,  # use raw connection for temp table visibility
                if_exists="append",
                index=False
            )

        # Merge into table
        engine = get_engine()
        with engine.begin() as conn:
            conn.execute(text(q_sql_createTable_fd))
            # conn.commit()
            conn.execute(text(q_sql_merge_fd))
            conn.commit()
    else:
        write_append(engine, df_final)

    # print(f"Done. Wrote {len(df_final):,} rows to [{p_sch}].[{p_tbl_fd}] in {p_db}.")
    engine.dispose()

    """
    Picklist Values
    """
    engine = get_engine()
    # Extract Picklist Values
    if UPSERT_ENABLED:
        # Create temp table
        with engine.begin() as conn:
            conn.execute(text(q_sql_createTemp_pl))
            conn.commit()
            # write_upsert(engine, df_final, q_sql_createTable_pl, temp_pl, q_sql_createTemp_pl, q_sql_merge_pl)
            df_pl.to_sql(
                schema='ids',
                name=temp_pl,
                con=engine,  # use raw connection for temp table visibility
                if_exists="append",
                index=False
            )

        # Merge into table
        engine = get_engine()
        with engine.begin() as conn:
            conn.execute(text(q_sql_createTable_pl))
            # conn.commit()
            conn.execute(text(q_sql_merge_pl))
            conn.commit()
    else:
        write_append(engine, df_pl)

    engine.dispose()


def extract_sfObject_metadata(sf: Salesforce, object_name: str) -> pd.DataFrame:
    """
    Extract field metadata for a given Salesforce object using REST describe
    and return a SQL-safe pandas DataFrame.
    """

    # REST describe call
    describe = sf.restful(f"sobjects/{object_name}/describe")
    fields = describe.get("fields", [])

    rows = []

    for f in fields:
        rows.append({
            "object_api_name": object_name,
            "field_api_name": f.get("name"),
            "field_label": f.get("label"),
            "description": f.get("description"),
            "data_type": f.get("type"),
            "length": f.get("length"),
            "precision": f.get("precision"),
            "scale": f.get("scale"),
            "nillable": f.get("nillable"),
            "unique": f.get("unique"),
            "calculated": f.get("calculated"),
            "calculated_formula": f.get("calculatedFormula"),
            "inline_help_text": f.get("inlineHelpText"),
            "reference_to": json.dumps(f.get("referenceTo"))
                             if f.get("referenceTo")
                             else None,
            "picklist_values": json.dumps([
                {
                    "value": pv.get("value"),
                    "label": pv.get("label"),
                    "active": pv.get("active"),
                    "default": pv.get("defaultValue")
                }
                for pv in f.get("picklistValues", [])
            ]) if f.get("picklistValues") else None
        })

    df_meta = pd.DataFrame(rows)

    # Final normalisation for SQL safety
    df_meta = df_meta.where(pd.notnull(df_meta), None)

    return df_meta

# def build_soql_count(EntityDefinition.QualifiedApiName: str, where_clause: Optional[str] = None) -> str:
#     """
#     Build a SELECT count() SOQL query. Safe for large objects since count() returns only the count.
#     """
#     base = f"SELECT count() FROM {EntityDefinition.QualifiedApiName}"
#     if where_clause:
#         base += f" WHERE {where_clause}"
#     return base


# def run_query_with_retries(sf: Salesforce, soql: str, query_all: bool = False) -> Dict[str, Any]:
#     """
#     Run a SOQL query with simple retry/backoff.
#     """
#     last_err = None
#     for attempt in range(1, MAX_RETRIES + 1):
#         try:
#             if query_all:
#                 return sf.query_all(soql)  # includes archived/deleted where applicable
#             else:
#                 return sf.query(soql)
#         except SalesforceGeneralError as e:
#             last_err = e
#             # Simple exponential backoff
#             time.sleep(RETRY_BACKOFF_SECONDS * attempt)
#         except Exception as e:
#             # Non-transient or unknown error
#             raise
#     # If we exhausted retries:
#     if last_err:
#         raise last_err


# def count_objects(
#     sf: Salesforce,
#     objects: List[str],
#     obj_where_clauses: Optional[Dict[str, str]] = None,
#     include_deleted: bool = False
# ) -> pd.DataFrame:
#     """
#     For each object in `objects`, executes SELECT count() and returns a DataFrame with results.

#     Columns:
#       - EntityDefinition.QualifiedApiName
#       - soql
#       - count
#       - success
#       - error
#     """
#     rows = []
#     obj_where_clauses = obj_where_clauses or {}

#     for obj in objects:
#         where_clause = obj_where_clauses.get(obj, "").strip() or None
#         soql = build_soql_count(obj, where_clause)
#         result_row = {"EntityDefinition.QualifiedApiName": obj, "soql": soql, "count": None, "success": False, "error": None}

#         try:
#             res = run_query_with_retries(sf, soql, query_all=include_deleted)
#             # For SELECT count(), Salesforce returns totalSize equal to the count,
#             # and 'records' is typically an empty list for count() queries.
#             cnt = res.get("totalSize")
#             result_row["count"] = int(cnt) if cnt is not None else None
#             result_row["success"] = True
#         except Exception as e:
#             result_row["error"] = str(e)
#             result_row["success"] = False

#         rows.append(result_row)

#     df = pd.DataFrame(rows, columns=["EntityDefinition.QualifiedApiName", "soql", "count", "success", "error"])
#     return df
