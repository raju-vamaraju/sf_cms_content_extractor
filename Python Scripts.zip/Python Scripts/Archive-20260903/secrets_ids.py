secrets = {
    'iflsetest': "{CQ{gM_488O-}Bz?A:/;Vb[PAsxb'q'%"
    # ,'pmanagertest': "/6!=b2e;h6w@jy-Jw8aGkV!+g[Ho1X9-"
    # ,'sfgtest': "!6;5FNUJc<7T?Yf8%N:|Al8\"qy9,?HTM"
    ,'pmanagertest': "KN^bP.)Tw]-XoqP8=]>,-e_;uTnTn>=;"
    ,'sfgtest': "S~\\N3|Ym]9?d;s}V=VTf4JD,3:A\\8RP#"
    # ,'pmanager': "p_vY=:\"{%4LUQXpc-E{~ig=Fm3{k8j4F"
    # ,'sfg': "m7@G6u(Y>T!Cq=Umm08frt9XU*H&P5bl"
    ,'pmanager': "YTP*2~`?vE;B6h|ShfB#*ilgiD,a=sHH"
    ,'sfg': "6G:N96OlBebI_0mTOD^wI%Lf-bU$Wlsn"
    ,'ri': "YTP*2~`?vE;B6h|ShfB#*ilgiD,a=sHH"
    ,'saAdviceSTG@hq.local': "2aThHwraszm8HCoDBxlv"
    ,'Rhombus-App-Ser\saAdvicePRD': "WazD*Dq8aH9@E@h"
    ,'Rhombus-App-Ser\saAdviceSTG': "D:Vf]#H-mawmgL6"
    ,'Rhombus-SQL-Ser\saAdvicePRD': "T7tft50_HJN-s4"
    ,'Rhombus-SQL-Ser\saAdviceSTG': "Yi+s?@2nfuHNKm"
    ,'rhpartial': {
        "site": "https://rhombusadvisory--rhpartial.sandbox.my.salesforce.com"
        ,"username": "rato.li@rhombusadvisory.com.au.rhpartial"
        ,"password": "l1qt360_on_BF26"
        ,"token": "Cuk49yhS21aED4ZFAtyduel3"
    }
    ,'rhdata': {
        "site": "https://rhombusadvisory--rhdata.sandbox.my.salesforce.com"
        ,"username": "rato.li@rhombusadvisory.com.au.rhdata"
        ,"password": "l1qt150_on_BF26"
        ,"token": "8TP3YJetVN35b77uiL2waDyz"
    }
    ,'rhuat': {
        "site": "https://test.salesforce.com"
        ,"username": "rato.li@rhombusenterprises.com.au.rhuat"
        ,"password": "l1qt100_on_BF26"
        ,"token": "9dRzBVWTJeJUaQ44cydP2fT2"
    }
    ,'datasb': {
        "site": "https://test.salesforce.com"
        ,"username": "rato.li@rhombusenterprises.com.au.datasb"
        ,"password": "l1qt150_on_BF26"
        ,"token": "kEOB2ptzqdrwOjfowjHGo9qJ"
    }
    ,'flow2sb': {
        "site": "https://test.salesforce.com"
        ,"username": "rato.li@rhombusenterprises.com.au.rhprod.flow2sb"
        ,"password": "l1qt360_on_BF26"
        ,"token": "Apnyiq7A6arGPaqKVKqmxb51"
    }
    ,'rhsit': {
        "site": "https://test.salesforce.com"
        ,"username": "rato.li@rhombusenterprises.com.au.rhprod.rhsit"
        ,"password": "l1qt400_on_BF26"
        ,"token": "w3jAWSZooDTiF79L5RokAZfBc"
    }
    ,'rhprod': {
        "site": "https://rhombusadvisory.my.salesforce.com"
        ,"username": "rato.li@rhombusenterprises.com.au.rhprod"
        ,"password": "l1qt260_on_BF26"
        ,"token": "wM2IbsikN9hLL8gnfxPT9mfvg"
    }
    ,'hubprod': {
        "site": "https://ioofadviserhub.my.salesforce.com"
        ,"username": "rato.li@rhombusadvisory.com.au"
        ,"password": "IFLPRODra123$"
        ,"token": "iFfQMUqe7HF4c7Ac9SNSwTYr"
    }
    ,'hubuat': {
        "site": "https://ioofadviserhub--hubuat.sandbox.lightning.force.com"
        ,"username": "rato.li@rhombusadvisory.com.au.hubuat"
        ,"password": "l1qt150_on_BF26"
        ,"token": "mlMvNgFbW6UiniZoBLt4M42zp"
    }
}  
